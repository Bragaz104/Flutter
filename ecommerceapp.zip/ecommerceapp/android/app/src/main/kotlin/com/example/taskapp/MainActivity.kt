package com.example.taskapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
